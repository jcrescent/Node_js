var my_module = require('./mathlib')();
console.log(my_module.random(5,30));